* ``Jun 16, 2015:`` Version 0.5.0 released.

* ``Oct 07, 2014:`` Version 0.4.6 released.

* ``Jul 06, 2014:`` Version 0.4.5 released.

* ``Jun 04, 2014:`` Version 0.4.4 released.

* ``Dec 19, 2013:`` Version 0.4.3 released.

* ``Dec 13, 2013:`` Version 0.4.2 released.

* ``Oct 17, 2013:`` *Python-evdev* is now available in `Ubuntu Saucy`_.

* ``Oct 11, 2013:`` *Python-evdev* is now available in `Arch Linux`_.

* ``Jul 24, 2013:`` Version 0.4.1 released.

* ``Jul 01, 2013:`` Version 0.4.0 released.

* ``May 29, 2013:`` Version 0.3.3 released.

* ``Apr 05, 2013:`` Version 0.3.2 released.

* ``Nov 23, 2012:`` Version 0.3.1 released.

* ``Nov 06, 2012:`` Version 0.3.0 released.

* ``Aug 22, 2012:`` Version 0.2.0 released.

* ``May 18, 2012:`` Version 0.1.1 released.

* ``May 17, 2012:`` Version 0.1.0 released.

.. _`Arch Linux`: https://aur.archlinux.org/packages/python-evdev/

.. _`Ubuntu Saucy`: http://packages.ubuntu.com/saucy/python-evdev
